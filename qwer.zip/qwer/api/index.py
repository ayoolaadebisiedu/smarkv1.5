from backend.main import app

# Vercel looks for 'app' by default in the specified file
# This bridges the root /api request to our FastAPI app inside the backend folder
